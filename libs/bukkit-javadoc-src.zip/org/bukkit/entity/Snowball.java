package org.bukkit.entity;

/**
 * Represents a snowball.
 */
public interface Snowball extends Projectile {}
