package org.bukkit.inventory;

public interface MerchantInventory extends Inventory {
}
